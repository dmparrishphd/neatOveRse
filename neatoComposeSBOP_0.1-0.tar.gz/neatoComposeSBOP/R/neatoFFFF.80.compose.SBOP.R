`%O%` <- function (FUN1, FUN2) function(...) FUN1(...) %|% FUN2

`%:O%` <- `%O%` %|% argswap
